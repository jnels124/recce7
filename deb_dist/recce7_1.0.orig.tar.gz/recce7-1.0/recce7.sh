#!/bin/bash
export RECCE7_OS_DIST=debian
python3 -m framework.frmwork
