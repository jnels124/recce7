from reportserver.server.SimpleHttpServer import SimpleHttpServer

server = SimpleHttpServer()
server.setupAndStart()